package com.example.trocadetelas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela2Activity extends AppCompatActivity {
    Button bttela1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        bttela1 = (Button) findViewById(R.id.bttela1);

        bttela1.setOnClickListener(new View.OnClickListener(){
            @Override
                    public void onClick(View view){
                Tela2Activity.this.finish();
            }
        });

    }
}