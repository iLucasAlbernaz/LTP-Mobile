package com.example.trocadetelas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.*;

public class MainActivity extends AppCompatActivity {

    Button bttela2;

    Intent itela2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bttela2 = (Button) findViewById(R.id.bttela2);

        bttela2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itela2 = new Intent(MainActivity.this,
                        Tela2Activity.class);
                startActivity(itela2);
            }
        });
    }
}