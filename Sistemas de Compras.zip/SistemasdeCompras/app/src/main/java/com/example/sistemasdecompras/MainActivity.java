package com.example.sistemasdecompras;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    CheckBox chkarroz, chkleite, chkcarne, chkfeijao;
    Button bttotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        chkarroz = findViewById(R.id.chkarroz);
        chkleite = findViewById(R.id.chkleite);
        chkcarne = findViewById(R.id.chkcarne);
        chkfeijao = findViewById(R.id.chkfeijao);
        bttotal = findViewById(R.id.bttotal);

        bttotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                double total = 0;
                if (chkarroz.isChecked()) total += 2.69;
                if (chkleite.isChecked()) total += 5.00;
                if (chkcarne.isChecked()) total += 10.90;
                if (chkfeijao.isChecked()) total += 2.30;

                if (total == 0) {
                    AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
                    dialogo.setTitle("Aviso");
                    dialogo.setMessage("Nenhum item foi selecionado.");
                    dialogo.setNeutralButton("OK", null);
                    dialogo.show();
                } else {
                    exibirOpcoesPagamento(total);
                }
            }
        });
    }

    private void exibirOpcoesPagamento(double total) {
        final String[] opcoesPagamento = {"Dinheiro", "PIX", "Cartão de Débito", "Cartão de Crédito"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Escolha a forma de pagamento");
        builder.setItems(opcoesPagamento, (dialog, which) -> {
            String formaPagamento = opcoesPagamento[which];
            AlertDialog.Builder confirmacao = new AlertDialog.Builder(MainActivity.this);
            confirmacao.setTitle("Confirmação");
            confirmacao.setMessage("Forma de pagamento escolhida: " + formaPagamento + "\nValor total: R$ " + String.format("%.2f", total));
            confirmacao.setNeutralButton("OK", null);
            confirmacao.show();
        });
        builder.show();
    }
}
