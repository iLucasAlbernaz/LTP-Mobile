package javaapplicationbanco;

public class ContaCorrenteComEncapsulamento {
    private int saldo;
    private int chequeEspecial;
    private int numeroSaque = 0;
    private int numeroDeposito = 0;


public ContaCorrenteComEncapsulamento(int saldo, int chequeEspecial) {
    this.saldo = saldo;
    this.chequeEspecial = chequeEspecial;
}

public int getSaldo(){
    return saldo;
}

public int getChequeEspecial() {
    return chequeEspecial;
 }

public void sacar(int valor) throws Exception {
        numeroSaque++;
        if (valor <= 0) 
            throw new Exception("Saque " + numeroSaque + " negado! Não podemos sacar um valor negativo ou zero: R$" + valor);

        if (valor > (saldo + chequeEspecial)) 
            throw new Exception("Saque " + numeroSaque + " negado! Saldo insuficiente! Você tem até R$" + (saldo + chequeEspecial) + " disponíveis (incluindo cheque especial).");

        saldo -= valor;

        System.out.println("\n------------------------------------------------------------------------------------------------------------------");
        if (saldo < 0) {
            System.out.println("Saque " + numeroSaque + " realizado com sucesso! Seu saldo está negativo: R$" + saldo);
            System.out.println("Você está usando R$" + (-saldo) + " do seu cheque especial. Limite restante: R$" + (chequeEspecial + saldo));
        } else {
            System.out.println("Saque " + numeroSaque + " realizado com sucesso! Saldo atual: R$" + saldo);
        }
        System.out.println("------------------------------------------------------------------------------------------------------------------\n");
    }

public void depositar(int valor) throws Exception {
        numeroDeposito++;

        if (valor <= 0) 
            throw new Exception("Depósito " + numeroDeposito + " negado! O valor deve ser maior que zero.");

        saldo += valor;

        System.out.println("\n------------------------------------------------------------------------------------------------------------------");
        System.out.println("Depósito " + numeroDeposito + " realizado com sucesso! Valor depositado: R$" + valor);
        System.out.println("Saldo atual: R$" + saldo);
        System.out.println("------------------------------------------------------------------------------------------------------------------\n");
    }
}