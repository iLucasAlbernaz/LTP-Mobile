//Mau Exemplo
/*
package javaapplicationbanco;

class ContaCorrente {
            public int saldo;
            public int chequeEspecial;
            
            public ContaCorrente(int saldo, int chequeEspecial){
                    this.saldo = saldo;
                    this.chequeEspecial = chequeEspecial;
           }
}
*/