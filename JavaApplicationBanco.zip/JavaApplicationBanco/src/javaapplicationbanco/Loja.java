/*
package javaapplicationbanco;

class Loja {
                public ContaCorrente minhaConta;
                
                public Loja(ContaCorrente minhaConta){
                            this.minhaConta = minhaConta;
                }
}
*/