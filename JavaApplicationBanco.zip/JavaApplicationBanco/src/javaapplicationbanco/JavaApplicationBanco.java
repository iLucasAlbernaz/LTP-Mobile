package javaapplicationbanco;

public class JavaApplicationBanco {
    public static void main(String[] args) {
        ContaCorrenteComEncapsulamento conta = new ContaCorrenteComEncapsulamento(1000, 500);

        System.out.println("Saldo inicial: R$" + conta.getSaldo());
        System.out.println("Saldo do Cheque Especial: R$" + conta.getChequeEspecial());

        try {
            
            conta.sacar(800);
     
            conta.sacar(600);
            
            conta.depositar(1000);
            
            conta.depositar(-5000);
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
