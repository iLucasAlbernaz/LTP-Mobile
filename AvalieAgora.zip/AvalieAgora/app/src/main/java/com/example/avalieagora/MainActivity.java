package com.example.avalieagora;

import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView txtstatus;
    RatingBar rtbvotacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtstatus = findViewById(R.id.txtstatus);
        rtbvotacao = findViewById(R.id.rtbvotacao);

        txtstatus.setText("Status: Ruim");
        rtbvotacao.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if (rating <= 1.0) {
                    txtstatus.setText("Status: Ruim");
                } else if (rating <= 2.0) {
                    txtstatus.setText("Status: Regular");
                } else if (rating <= 3.0) {
                    txtstatus.setText("Status: Bom");
                } else if (rating <= 4.0) {
                    txtstatus.setText("Status: Ótimo");
                } else if (rating == 5.0) {
                    txtstatus.setText("Status: Exelente");
                }
            }
        });
    }
}
